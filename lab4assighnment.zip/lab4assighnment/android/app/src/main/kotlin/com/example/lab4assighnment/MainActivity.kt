package com.example.lab4assighnment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
